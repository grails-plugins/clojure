ant.mkdir dir: "${basedir}/src/clj"
